DROP TABLE IF EXISTS `#__vpetrenko_students`;
